package com.mfa.utils

import android.graphics.Bitmap
import android.graphics.Canvas

class CameraImageGraphic(graphicOverlay: GraphicOverlay, originalCameraImage: Bitmap) : GraphicOverlay.Graphic(
    graphicOverlay
) {
    private val bitmap: Bitmap
    init {
        this.bitmap = originalCameraImage;
    }
    override fun draw(canvas: Canvas?) {
        canvas!!.drawBitmap(bitmap, getTransformationMatrix(), null);
    }

}
