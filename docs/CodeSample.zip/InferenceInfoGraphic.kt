package com.mfa.utils

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

class InferenceInfoGraphic(
    overlay: GraphicOverlay,
    currentFrameLatencyMs: Long,
    currentDetectorLatencyMs: Long,
    currentFramesPerSecond: Int
) : GraphicOverlay.Graphic(overlay) {
    private val TEXT_COLOR: Int = Color.WHITE
    private val TEXT_SIZE = 60.0f

    private var textPaint: Paint
    private var graphicOverlay: GraphicOverlay
    private var frameLatency: Long
    private var detectorLatency: Long

    // Only valid when a stream of input images is being processed. Null for single image mode.
    private var framesPerSecond: Int
    private val showLatencyInfo = true

    init {
        this.graphicOverlay = overlay
        this.frameLatency = currentFrameLatencyMs
        this.detectorLatency = currentDetectorLatencyMs
        this.framesPerSecond = currentFramesPerSecond
        textPaint = Paint()
        textPaint.setColor(TEXT_COLOR)
        textPaint.setTextSize(TEXT_SIZE)
        textPaint.setShadowLayer(5.0f, 0f, 0f, Color.BLACK)
        postInvalidate()
    }

    override fun draw(canvas: Canvas?) {
        val x = TEXT_SIZE * 0.5f
        val y = TEXT_SIZE * 1.5f

        canvas!!.drawText(
            "InputImage size: " + overlay.getImageHeight() + "x" + overlay.getImageWidth(),
            x,
            y,
            textPaint
        )

        if (!showLatencyInfo) {
            return
        }

        // Draw FPS (if valid) and inference latency
        canvas.drawText(
            "FPS: $framesPerSecond, Frame latency: $frameLatency ms",
            x,
            y + TEXT_SIZE,
            textPaint
        )
        canvas.drawText(
            "Detector latency: $detectorLatency ms", x, y + TEXT_SIZE * 2, textPaint
        )
    }

}
